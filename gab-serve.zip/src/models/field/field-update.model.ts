import { Field } from 'src/schemas/field.schema';

export class FieldUpdate {
  sid: string;
  field: Field;
}
