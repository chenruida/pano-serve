import { ErrorsFilter } from './errors.filter';

describe('ErrorsFilter', () => {
  it('should be defined', () => {
    expect(new ErrorsFilter()).toBeDefined();
  });
});
